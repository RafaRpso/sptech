package com.example.loginKelvin02221014;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
@RestController
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();


    @PostMapping("/usuarios")
    public Usuario cadastrarUsuario(@RequestBody Usuario novoUsuario) {
        novoUsuario.setAutenticado(false);
        usuarios.add(novoUsuario);
        novoUsuario.setSenha(null);
        return novoUsuario;
    }

    @PostMapping("/usuarios/autenticacao/{usuario}/{senha}")
    public Usuario autenticarUsuario(@PathVariable String usuario, @PathVariable String senha) {
        Optional<Usuario> usuarioAutenticado = usuarios.stream()
                .filter(u -> u.getUsuario().equals(usuario) && u.getSenha().equals(senha))
                .findFirst();

        if (usuarioAutenticado.isPresent()) {
            Usuario usuarioEncontrado = usuarioAutenticado.get();
            usuarioEncontrado.setAutenticado(true);
            usuarioEncontrado.setSenha(null);
            return usuarioEncontrado;
        } else {
            return null;
        }
    }

    @GetMapping("/usuarios")
    public List<Usuario> listarUsuarios() {
        usuarios.forEach(u -> u.setSenha(null));
        return usuarios;
    }

    @DeleteMapping("/usuarios/autenticacao/{usuario}")
    public String fazerLogoff(@PathVariable String usuario) {
        Optional<Usuario> usuarioLogoff = usuarios.stream()
                .filter(u -> u.getUsuario().equals(usuario))
                .findFirst();

        if (usuarioLogoff.isPresent()) {
            Usuario usuarioEncontrado = usuarioLogoff.get();
            if (usuarioEncontrado.isAutenticado()) {
                usuarioEncontrado.setAutenticado(false);
                return "Logoff do usuário " + usuarioEncontrado.getNome() + " concluído";
            } else {
                return "Usuário " + usuarioEncontrado.getNome() + " Não está autenticado";
            }
        } else {
            return "Usuário " + usuario + " não encontrado";
        }
    }

    // Esse tem como objetivo criar uma nova postagem para um determinado usuário
    @PostMapping("/usuarios/{usuario}/postagens")
    public String criarPostagem(@PathVariable String usuario, @RequestBody Postagem postagem) {
        for (Usuario u : usuarios) {
            if (u.getNome().equals(usuario)) {
                u.getPostagens().add(postagem);
                return "Postagem criada com sucesso!";
            }
        }
        return "Usuário não encontrado.";
    }

}