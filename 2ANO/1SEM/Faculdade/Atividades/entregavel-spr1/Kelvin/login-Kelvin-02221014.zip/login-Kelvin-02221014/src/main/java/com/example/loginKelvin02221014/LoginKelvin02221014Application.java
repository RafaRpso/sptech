package com.example.loginKelvin02221014;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginKelvin02221014Application {

	public static void main(String[] args) {
		SpringApplication.run(LoginKelvin02221014Application.class, args);
	}

}
