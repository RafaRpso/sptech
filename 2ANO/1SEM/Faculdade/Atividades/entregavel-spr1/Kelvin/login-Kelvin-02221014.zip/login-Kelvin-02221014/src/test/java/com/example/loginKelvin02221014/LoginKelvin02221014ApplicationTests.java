package com.example.loginKelvin02221014;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginKelvin02221014ApplicationTests {

	@Test
	void contextLoads() {
	}

}
