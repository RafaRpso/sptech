package sptech.school.loginlogoffprojeto0221022;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginLogoffProjeto0221022Application {

	public static void main(String[] args) {
		SpringApplication.run(LoginLogoffProjeto0221022Application.class, args);
	}

}
