package sptech.school.loginlogoffprojeto0221022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginLogoffProjeto0221022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
