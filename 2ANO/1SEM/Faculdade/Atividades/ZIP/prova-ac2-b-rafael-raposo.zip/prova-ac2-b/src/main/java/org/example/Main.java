package org.example;

public class Main {
    public static void main(String[] args) {
        CaixaEletronico caixa = new CaixaEletronico();

        caixa.sacar(500);
    }
}