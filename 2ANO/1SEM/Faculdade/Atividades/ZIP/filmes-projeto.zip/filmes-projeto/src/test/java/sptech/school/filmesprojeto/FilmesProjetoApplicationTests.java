package sptech.school.filmesprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmesProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
