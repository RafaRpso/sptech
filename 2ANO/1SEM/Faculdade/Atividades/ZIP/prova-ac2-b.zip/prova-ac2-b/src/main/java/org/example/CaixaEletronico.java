package org.example;

public class CaixaEletronico {

    private int quantidadeNotasQuinhentos;
    private int quantidadeNotasDuzentos;
    private int quantidadeNotasCem;
    private int quantidadeNotasCinquenta;
    private int quantidadeNotasVinte;
    private int quantidadeNotasDez;
    private int quantidadeNotasCinco;
    private int quantidadeNotasUm;

    private Double[] mediaLinha = new Double[8];
    private Double[] mediaColuna = new Double[3];

    public int getQuantidadeNotasQuinhentos() {
        return quantidadeNotasQuinhentos;
    }

    public int getQuantidadeNotasDuzentos() {
        return quantidadeNotasDuzentos;
    }

    public int getQuantidadeNotasCem() {
        return quantidadeNotasCem;
    }

    public int getQuantidadeNotasCinquenta() {
        return quantidadeNotasCinquenta;
    }

    public int getQuantidadeNotasVinte() {
        return quantidadeNotasVinte;
    }

    public int getQuantidadeNotasDez() {
        return quantidadeNotasDez;
    }

    public int getQuantidadeNotasCinco() {
        return quantidadeNotasCinco;
    }

    public int getQuantidadeNotasUm() {
        return quantidadeNotasUm;
    }

    public void sacar(int valor) {
    }

    /* Calcula a media das linhas e coloca as medias no vetor mediaLinha
       Calcula a media das colunas e coloca as medias no vetor mediaColuna
       Não esqueca de exibir na console o relatorio formatado conforme enunciado
    */
    public void exibeRelatorio(int[][] m) {

    }

    public Double[] getMediaLinha() {
        return mediaLinha;
    }
    public Double[] getMediaColuna() {
        return mediaColuna;
    }

}
