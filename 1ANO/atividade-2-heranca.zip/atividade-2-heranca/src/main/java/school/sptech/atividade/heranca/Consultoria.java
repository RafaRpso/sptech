/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package school.sptech.atividade.heranca;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aluno
 */
public class Consultoria {
    protected List <Desenvolvedor> dev; 
    private Integer vagas ; 
    private String nome ; 

    public Consultoria( Integer vagas, String nome) {
        this.dev = new ArrayList<>();
        this.vagas = vagas;
        this.nome = nome;
    }
    
    
    
    
    public Boolean existePorNome(String nomeDesenvolvedor) { 
        
        for (Desenvolvedor i : dev){ 
            if ( i.getNome().equals(nomeDesenvolvedor) ) { 
                return true ; 
            }
        }
        return false ; 
    }
    
    public void contratar(Desenvolvedor desenvolvedor) { 
        if (this.vagas > 0 && !existePorNome(desenvolvedor.getNome())){ 
            dev.add(desenvolvedor); 
        }
    }
    
    public Integer getQuantidadeDesenvolvedores() { 
        return dev.size() ; 
    }
    
    public Integer getQuantidadeDesenvolvedoresMobile() { 
        Integer qtdDevs = 0 ;
        for (Desenvolvedor i : dev){ 
            if (i instanceof DesenvolvedorMobile){ 
                qtdDevs++; 
            }
        }
        return qtdDevs; 
    }
    public Double getTotalSalarios() { 
       return dev.stream().mapToDouble(desenv ->  desenv.getSalario() ).sum() ;
    }
    
    public Desenvolvedor buscarDesenvolvedorPeloNome(String nome ) { 
        for (Desenvolvedor i : dev ) { 
            if ( i.getNome().toLowerCase().equals(nome.toLowerCase())) { 
                return i ; 
            }
        }
        return null ; 
    }    

    public List<Desenvolvedor> getDev() {
        return dev;
    }

    public void setDev(List<Desenvolvedor> dev) {
        this.dev = dev;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
        
}
