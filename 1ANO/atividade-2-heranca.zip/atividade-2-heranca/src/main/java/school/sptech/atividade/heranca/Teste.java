/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package school.sptech.atividade.heranca;

/**
 *
 * @author aluno
 */
public class Teste {
    public static void main(String[] args) {
        Consultoria consultoria = new Consultoria(3,"Rapoposo") ; 
        Desenvolvedor dev1 = new Desenvolvedor("Brayan",12.00,90) ;
        Desenvolvedor dev2 = new Desenvolvedor("Rafael", 99.99, 6); 
        Desenvolvedor dev3 = new DesenvolvedorMobile("Cleber", 500.00, 2);  
        
        consultoria.contratar(dev1);
        consultoria.contratar(dev2);
        consultoria.contratar(dev3);
            
        System.out.println(consultoria.existePorNome("Rafael"));
        System.out.println(consultoria.getQuantidadeDesenvolvedores());
        System.out.println(consultoria.getQuantidadeDesenvolvedoresMobile());
        System.out.println(consultoria.getTotalSalarios());
    }
    
    
    
}
