/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package school.sptech.atividade.heranca;

/**
 *
 * @author aluno
 */
public class Desenvolvedor {
    private String nome ; 
    private Double valorHorasTrabalhadas ; 
    private Integer qtdHorasTrabalhadas;

    public Desenvolvedor(String nome, Double valorHorasTrabalhadas, Integer qtdHorasTrabalhadas) {
        this.nome = nome;
        this.valorHorasTrabalhadas = valorHorasTrabalhadas;
        this.qtdHorasTrabalhadas = qtdHorasTrabalhadas;
    }

  
    
    
    public Double getSalario() { 
        return this.valorHorasTrabalhadas * this.qtdHorasTrabalhadas ; 
    }
 
    @Override
    public String toString() { 
        return "Nome: " + this.nome + "\nValor por horas trabalhadas: " + this.valorHorasTrabalhadas + "Quantidade de horas trabalhadas " + this.qtdHorasTrabalhadas;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValorHorasTrabalhadas() {
        return valorHorasTrabalhadas;
    }

    public void setValorHorasTrabalhadas(Double valorHorasTrabalhadas) {
        this.valorHorasTrabalhadas = valorHorasTrabalhadas;
    }

    public Integer getQtdHorasTrabalhadas() {
        return qtdHorasTrabalhadas;
    }

    public void setQtdHorasTrabalhadas(Integer qtdHorasTrabalhadas) {
        this.qtdHorasTrabalhadas = qtdHorasTrabalhadas;
    }
    
    
    
       
   
}
