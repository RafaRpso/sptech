/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package school.sptech.atividade.heranca;

/**
 *
 * @author aluno
 */
public class DesenvolvedorMobile extends Desenvolvedor {

    
    private Integer qtdHorasTrabalhadasMobile ;
    private Double valorHorasTrabalhadasMobile ; 
    
    
    public DesenvolvedorMobile(String nome, Double valorHorasTrabalhadas, Integer qtdHorasTrabalhadas) {
        super(nome, valorHorasTrabalhadas, qtdHorasTrabalhadas);
        this.qtdHorasTrabalhadasMobile = qtdHorasTrabalhadas; 
        this.valorHorasTrabalhadasMobile = valorHorasTrabalhadas; 
    }
    @Override
    public Double getSalario() { 
        return this.qtdHorasTrabalhadasMobile * this.valorHorasTrabalhadasMobile ; 
    }
    

    public Integer getQtdHorasTrabalhadasMobile() {
        return qtdHorasTrabalhadasMobile;
    }

    public void setQtdHorasTrabalhadasMobile(Integer qtdHorasTrabalhadasMobile) {
        this.qtdHorasTrabalhadasMobile = qtdHorasTrabalhadasMobile;
    }

    public Double getValorHorasTrabalhadasMobile() {
        return valorHorasTrabalhadasMobile;
    }

    public void setValorHorasTrabalhadasMobile(Double valorHorasTrabalhadasMobile) {
        this.valorHorasTrabalhadasMobile = valorHorasTrabalhadasMobile;
    }
    
    
   
}
