package school.sptech.avaliacao.continuada2.incompleto;

/*

 Substitua os valores abaixo com seus dados:

 RA: 02221022
 NOME: RAFAEL ALVES RAPOSO
 TURMA: 1-CCO
  
 ATENÇÃO!!!
 RESOLVA OS ERROS DE COMPILAÇÃO ANTES DE RODAR QUALQUER TESTE

 */
public class Concessionaria {

    private String nome;
    private Integer quantidadeVendas;
    private Integer quantidadeDescontosAplicados;
    private Double totalVendido;

    public Concessionaria(String nome) {
        this.quantidadeVendas = 0;
        this.quantidadeDescontosAplicados = 0;
        this.totalVendido = 0.0;
    }

    public void aumentarEstoque(Veiculo veiculo, Integer quantidade) {
        if (veiculo != null && quantidade != null && quantidade > 0) {
            veiculo.setQuantidadeEstoque(veiculo.getQuantidadeEstoque() + quantidade);
        }
    }

    public void realizarVenda(Veiculo veiculo) {
        if (veiculo.getQuantidadeEstoque() > 0 && veiculo.getValorTabela() > 0) {
            veiculo.setQuantidadeEstoque(veiculo.getQuantidadeEstoque() - 1);
            this.totalVendido += veiculo.getValorTabela();
            this.quantidadeVendas += 1;
        }
    }

    public void realizarVenda(Veiculo veiculo, Double porcentagemDesconto) {

        if (veiculo != null && veiculo.getQuantidadeEstoque() > 0 && veiculo.getValorTabela() > 0 && porcentagemDesconto != null && porcentagemDesconto > 0) {
            Double valorFinal = veiculo.getValorTabela() - (veiculo.getValorTabela() * (porcentagemDesconto / 100.0));
            veiculo.setQuantidadeEstoque(veiculo.getQuantidadeEstoque() - 1);
            this.totalVendido += valorFinal;
            this.quantidadeVendas += 1;
            this.quantidadeDescontosAplicados += 1;
        }
    }

    public Double getPercentualVendasComDesconto() {
        if (this.quantidadeVendas <= 0) {
            return 0.0;
        } else if (this.quantidadeVendas == this.quantidadeDescontosAplicados) {
            return 100.0;
        } else {
            return (this.quantidadeDescontosAplicados * 100.0) / this.quantidadeVendas;
        }
    }

    public String getNome() {
        return nome;
    }

    public Integer getQuantidadeVendas() {
        return quantidadeVendas;
    }

    public Integer getQuantidadeDescontosAplicados() {
        return quantidadeDescontosAplicados;
    }

    public Double getTotalVendido() {
        return totalVendido;
    }

}
