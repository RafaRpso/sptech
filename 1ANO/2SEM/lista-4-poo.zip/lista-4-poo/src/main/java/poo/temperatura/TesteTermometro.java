/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.temperatura;

/**
 *
 * @author rafaelraposo
 */
public class TesteTermometro {
    public static void main(String[] args) {
        Termometro termometro1 = new Termometro(25.2,0.3,90.0) ;
        termometro1.exibeFahreinheit();
       
        
    }
}
