/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package poo.bolo;

/**
 *
 * @author rafaelraposo
 */
public class App {

    public static void main(String[] args) {
        Bolo bolo = new Bolo("Morango",25.05,4) ; 
        Bolo bolo1 = new Bolo("Chocolate",40.50,9); 
        Bolo bolo2 = new Bolo("Abacaxi",10.10, 3); 
        
        bolo.comprarBolo(4);
        bolo1.comprarBolo(10);
        bolo2.comprarBolo(70);
        bolo.comprarBolo(4); 
        bolo.comprarBolo(2); 
        
        System.out.println(bolo.exibirRelatorio());
        System.out.println(bolo1.exibirRelatorio());
        System.out.println(bolo2.exibirRelatorio());
    
        
    }
}
