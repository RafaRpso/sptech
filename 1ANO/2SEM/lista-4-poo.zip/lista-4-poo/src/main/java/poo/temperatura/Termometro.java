/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.temperatura;

/**
 *
 * @author rafaelraposo
 */
public class Termometro {

    private Double temperaturaAtual;
    private Double temperaturaMin;
    private Double temperaturaMax;

    public Termometro(Double temperaturaAtual, Double temperaturaMin, Double temperaturaMax) {
        this.temperaturaAtual = temperaturaAtual;
        this.temperaturaMin = temperaturaMin;
        this.temperaturaMax = temperaturaMax;
    }

    public Double compararValorMax(Double valor) {
        if (valor > this.temperaturaMax) {
            return this.temperaturaMax;
        } else {
            return valor;
        }

    }

    public Double compararValorMin(Double valor) {
        if (valor < this.temperaturaMin) {
            return this.temperaturaMin;
        } else {
            return valor;
        }

    }
    public void exibeFahreinheit(){
        System.out.println("F°: "+(this.temperaturaAtual* 9/5) + 32 );
    }
    public void aumentaTemperatura(Double valor) {
        valor = compararValorMax(valor);
        this.temperaturaAtual += valor;
    }

    public void diminuirTemperatura(Double valor) {
        valor = compararValorMin(valor);
        this.temperaturaAtual -= valor;
    }

    public void setTemperaturaAtual(Double temperaturaAtual) {
        this.temperaturaAtual = temperaturaAtual;
    }

    public void setTemperaturaMin(Double temperaturaMin) {
        this.temperaturaMin = temperaturaMin;
    }

    public void setTemperaturaMax(Double temperaturaMax) {
        this.temperaturaMax = temperaturaMax;
    }

    public Double getTemperaturaAtual() {
        return temperaturaAtual;
    }

    public Double getTemperaturaMin() {
        return temperaturaMin;
    }

    public Double getTemperaturaMax() {
        return temperaturaMax;
    }
}
