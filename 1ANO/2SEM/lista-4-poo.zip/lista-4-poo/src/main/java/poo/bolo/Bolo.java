/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.bolo;

public class Bolo {

    private String sabor;
    private Double valor;
    private Integer qtdVendida;

    // constructor 
    public Bolo(String sabor, Double valor, Integer qtdVendida) {
        this.sabor = sabor;
        this.valor = valor;
        this.qtdVendida = qtdVendida;
    }

    public void comprarBolo(Integer qtdBolo) {
        if (isQtdVendidaValid(qtdBolo)) {
            this.qtdVendida += qtdBolo;
        } else {
            System.out.println("Seu pedido ultrapassou nosso limite diário para esse bolo.");
        }

    }

    public String exibirRelatorio() {
        return String.format("O bolo de sabor %s, foi comprado %d, totalizando %f", this.sabor, this.qtdVendida, totalGastoBolo());

    }
    public Double totalGastoBolo() { 
        return this.valor * this.qtdVendida; 
    } 
    public Boolean isSaborValid(String sabor) {
        return sabor.equals("chocolate".toLowerCase())
                || sabor.equals("abacaxi".toLowerCase())
                || sabor.equals("morango".toLowerCase());
    }

    public Boolean isValorValid(Double val) {
        return val >= 30.0 && val <= 50.0;
    }

    public Boolean isQtdVendidaValid(Integer qtdVendida) {
        return qtdVendida <= 100 && qtdVendida > 0;
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        if (isSaborValid(sabor)) {
            this.sabor = sabor;
        }
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        if (isValorValid(valor)) {
            this.valor = valor;
        }
    }

    public Integer getQtdVendida() {
        return qtdVendida;
    }

    public void setQtdVendida(Integer qtdVendida) {
        if (isQtdVendidaValid(qtdVendida)) {
            this.qtdVendida = qtdVendida;
        }
    }

}
