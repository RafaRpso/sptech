/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.etiqueta;

public class Etiqueta {

    private Character tamanho;
    private String enderecoRemetente;
    private String enderecoDestinatario;
    private Double distancia;
    private Double valorEncomenda;

    public void emitirEtiqueta() {
        String tamanhoString = conversaoTamanhoNome();
        System.out.println("*".repeat(5) + "Etiqueta para envio " + "*".repeat(5));
        System.out.println("Endereço do remetente: " + this.enderecoRemetente);
        System.out.println("Endereço do destinatário : " + this.enderecoDestinatario);
        System.out.println("Tamanho: " + tamanhoString);
        System.out.println("-".repeat(10));
        System.out.println("Valor encomenda: R$" + this.valorEncomenda);
        System.out.println("Valor frete: R$" + calcularFrete());
        System.out.println("-".repeat(10));
        System.out.println("Valor total: R$" + (calcularFrete() + this.valorEncomenda));

    }

    public String conversaoTamanhoNome() {
        if (this.tamanho.equals("P")) {
            return "Pequeno";
        } else if (this.tamanho.equals("M")) {
            return "Médio";
        } else if (this.tamanho.equals("G")) {
            return "Grande";
        }
        return null;
    }

    public Double calcularFrete() {
        Double frete = calcularDistancia();
        return frete;
    }

    public Double calcularDistancia() {
        Double frete = calcularPorcentagem();

        if (this.distancia <= 50) {
            frete += 3;
        } else if (this.distancia >= 51 && distancia <= 200) {
            frete += 5;
        } else if (this.distancia > 200) {
            frete += 7;
        }
        return frete;

    }

    public Double calcularPorcentagem() {
        Double frete = 0.0;
        if (this.tamanho.equals("P")) {
            frete = this.valorEncomenda * 0.01;
        } else if (this.tamanho.equals("M")) {
            frete = this.valorEncomenda * 0.03;
        } else if (this.tamanho.equals("G")) {
            frete = this.valorEncomenda * 0.05;
        }

        return frete;
    }

    public Character getTamanho() {
        return tamanho;
    }

    public String getEnderecoRemetente() {
        return enderecoRemetente;
    }

    public String getEnderecoDestinatario() {
        return enderecoDestinatario;
    }

    public Double getDistancia() {
        return distancia;
    }

    public Double getValorEncomenda() {
        return valorEncomenda;
    }

    public void setTamanho(Character tamanho) {
        if (this.tamanho.equals("G") || this.tamanho.equals("M") || this.tamanho.equals("P")) {
            this.tamanho = tamanho;
        } else {
            this.tamanho = null;
        }
    }

    public void setEnderecoRemetente(String enderecoRemetente) {
        this.enderecoRemetente = enderecoRemetente;
    }

    public void setEnderecoDestinatario(String enderecoDestinatario) {
        this.enderecoDestinatario = enderecoDestinatario;
    }

    public void setDistancia(Double distancia) {
        if (distancia > 0) {
            this.distancia = distancia;
        } else {
            this.distancia = null;
        }

    }

    public void setValorEncomenda(Double valorEncomenda) {
        this.valorEncomenda = valorEncomenda;
    }

}
