/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.empregado;

/**
 *
 * @author rafaelraposo
 */
public class TesteEmpregado {
    public static void main(String[] args) {
        Empregado empregado1 = new Empregado("João", "Analista de sistemas",5400.00);
        System.out.println("Nome:  "+empregado1.getNome()+"\nCargo: " + empregado1.getCargo()+"\nSalário reajustado: "+empregado1.reajustarSalario(15) );
        
    }
}
